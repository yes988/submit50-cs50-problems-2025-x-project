package com.example.calorie;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;




public class MainActivity extends Activity {

    EditText etName, etAge, etWeight;
    RadioButton rbMale, rbFemale;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        etWeight = findViewById(R.id.etWeight);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etName.getText().toString();
                String weightStr = etWeight.getText().toString();
                String gender = "";

                if (rbMale.isChecked()) {
                    gender = "Male";
                } else if (rbFemale.isChecked()) {
                    gender = "Female";
                }

                double weight = Double.parseDouble(weightStr);

                Intent intent = new Intent(MainActivity.this, FirstFragment.class);
                intent.putExtra("name", name);
                intent.putExtra("gender", gender);
                intent.putExtra("weight", weight);
                startActivity(intent);
            }
        });
    }
}
