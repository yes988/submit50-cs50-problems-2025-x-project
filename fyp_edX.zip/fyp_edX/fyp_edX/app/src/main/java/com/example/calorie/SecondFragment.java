package com.example.calorie;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;




public class SecondFragment extends Activity {

    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_second);

        tvResult = findViewById(R.id.tvResult);

        double pace = getIntent().getDoubleExtra("pace", 0);
        double calPerMin = getIntent().getDoubleExtra("calPerMin", 0);
        double totalCal = getIntent().getDoubleExtra("totalCal", 0);

        String result = String.format("Running Pace: %.2f min/km\nCalories Burned/Min: %.2f\nTotal Calories Burned: %.2f",
                pace, calPerMin, totalCal);

        tvResult.setText(result);
    }
}
