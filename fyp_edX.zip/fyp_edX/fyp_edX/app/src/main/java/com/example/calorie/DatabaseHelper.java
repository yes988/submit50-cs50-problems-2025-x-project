package com.example.calorie;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "workouts.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "workout_data";
    public static final String COL_ID = "id";
    public static final String COL_DURATION = "duration";
    public static final String COL_DISTANCE = "distance";
    public static final String COL_PACE = "pace";
    public static final String COL_CAL_PER_MIN = "calories_per_minute";
    public static final String COL_TOTAL_CAL = "total_calories";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_DURATION + " REAL, " +
                COL_DISTANCE + " REAL, " +
                COL_PACE + " REAL, " +
                COL_CAL_PER_MIN + " REAL, " +
                COL_TOTAL_CAL + " REAL)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean insertWorkout(double duration, double distance, double pace, double calPerMin, double totalCal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_DURATION, duration);
        values.put(COL_DISTANCE, distance);
        values.put(COL_PACE, pace);
        values.put(COL_CAL_PER_MIN, calPerMin);
        values.put(COL_TOTAL_CAL, totalCal);
        long result = db.insert(TABLE_NAME, null, values);
        return result != -1;
    }
}
