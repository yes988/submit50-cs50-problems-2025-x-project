package com.example.calorie;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;


public class FirstFragment extends Activity {
    DatabaseHelper dbHelper;

    TextView tvMessage;
    EditText etDuration, etDistance;
    Button btnCalcu;

    String name, gender;
    double weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_first);

        dbHelper = new DatabaseHelper(this);


        tvMessage = findViewById(R.id.tvMessage);
        etDuration = findViewById(R.id.etDuration);
        etDistance = findViewById(R.id.etDistance);
        btnCalcu = findViewById(R.id.btnCalcu);

        Intent intent = getIntent();
        name = intent.getStringExtra("name");
        gender = intent.getStringExtra("gender");
        weight = intent.getDoubleExtra("weight", 0);

        String salutation = gender.equals("Male") ? "Mr." : "Ms.";
        tvMessage.setText("Welcome " + salutation + " " + name);

        btnCalcu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double duration = Double.parseDouble(etDuration.getText().toString());
                double distance = Double.parseDouble(etDistance.getText().toString());

                double pace = duration / distance;
                double caloriesPerMinute = (pace * weight * 3.5) / 200;
                double totalCalories = caloriesPerMinute * duration;

                dbHelper.insertWorkout(duration, distance, pace, caloriesPerMinute, totalCalories);

                Intent resultIntent = new Intent(FirstFragment.this, SecondFragment.class);
                resultIntent.putExtra("pace", pace);
                resultIntent.putExtra("calPerMin", caloriesPerMinute);
                resultIntent.putExtra("totalCal", totalCalories);
                startActivity(resultIntent);
            }
        });
    }
}
